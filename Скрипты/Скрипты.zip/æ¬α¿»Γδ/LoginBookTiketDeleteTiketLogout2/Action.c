Action()
{

	lr_start_transaction("����������� ���������� �����");


/*Correlation comment - Do not change!  Original value='Frankfurt' Name ='depart' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=depart",
		"RegExp=option\\ value=\"(.*?)\">Frankfurt",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/reservations.pl*",
		LAST);

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t3.inf", 
		LAST);

	web_add_auto_header("Origin", 
		"http://localhost:1080");

	lr_think_time(20);

/*Correlation comment - Do not change!  Original value='120;499;07/04/2024' Name ='outboundFlight' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=outboundFlight",
		"TagName=input",
		"Extract=value",
		"Name=outboundFlight",
		"Type=radio",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		LAST);

	web_submit_form("reservations.pl",
		"Snapshot=t4.inf",
		ITEMDATA,
		"Name=depart", "Value={depart}", ENDITEM,
		"Name=departDate", "Value={departDate}", ENDITEM,
		"Name=arrive", "Value={arrive}", ENDITEM,
		"Name=returnDate", "Value={returnDate}", ENDITEM,
		"Name=numPassengers", "Value=2", ENDITEM,
		"Name=roundtrip", "Value=<OFF>", ENDITEM,
		"Name=seatPref", "Value={seatPref}", ENDITEM,
		"Name=seatType", "Value={seatType}", ENDITEM,
		LAST);

	lr_think_time(4);
lr_end_transaction("����������� ���������� �����", LR_AUTO);

lr_start_transaction("������ ���������");

/*Correlation comment - Do not change!  Original value='Kaliningrad' Name ='address2' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=address2",
		"TagName=input",
		"Extract=value",
		"Name=address2",
		"Type=text",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		LAST);

/*Correlation comment - Do not change!  Original value='Mikhail' Name ='firstName' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=firstName",
		"TagName=input",
		"Extract=value",
		"Name=firstName",
		"Type=text",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		LAST);


/*Correlation comment - Do not change!  Original value='1111111' Name ='creditCard' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=creditCard",
		"TagName=input",
		"Extract=value",
		"Name=creditCard",
		"Type=text",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		LAST);

/*Correlation comment - Do not change!  Original value='11/11' Name ='expDate' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=expDate",
		"RegExp=name=\"expDate\"\\ value=\"(.*?)&\\#10",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
lr_end_transaction("������ ���������", LR_AUTO);
lr_start_transaction("���������� ������");

	web_submit_form("reservations.pl_2",
		"Snapshot=t5.inf",
		ITEMDATA,
		"Name=outboundFlight", "Value={outboundFlight}", ENDITEM,
		"Name=reserveFlights.x", "Value=52", ENDITEM,
		"Name=reserveFlights.y", "Value=8", ENDITEM,
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_submit_form("reservations.pl_3",
		"Snapshot=t6.inf",
		ITEMDATA,
		"Name=firstName", "Value={firstName}", ENDITEM,
		"Name=lastName", "Value={firstName}", ENDITEM,
		"Name=address1", "Value=zorge", ENDITEM,
		"Name=address2", "Value={address2}", ENDITEM,
		"Name=pass1", "Value={firstName} {firstName}", ENDITEM,
		"Name=pass2", "Value=", ENDITEM,
		"Name=creditCard", "Value={creditCard}", ENDITEM,
		"Name=expDate", "Value={expDate}", ENDITEM,
		"Name=saveCC", "Value=<OFF>", ENDITEM,
		LAST);

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(4);
	lr_end_transaction("���������� ������", LR_AUTO);

lr_start_transaction("�������� ���������");

	web_image("Home Button", 
		"Alt=Home Button", 
		"Snapshot=t7.inf", 
		LAST);

lr_end_transaction("�������� ���������", LR_AUTO);


	return 0;
}