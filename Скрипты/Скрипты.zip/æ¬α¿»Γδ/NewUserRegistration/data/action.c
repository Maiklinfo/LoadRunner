Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Microsoft Edge\";v=\"126\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_link("sign up now", 
		"Text=sign up now", 
		"Snapshot=t2.inf", 
		LAST);

	web_add_auto_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_form("login.pl", 
		"Snapshot=t3.inf", 
		ITEMDATA, 
		"Name=username", "Value=sss", ENDITEM, 
		"Name=password", "Value=111", ENDITEM, 
		"Name=passwordConfirm", "Value=111", ENDITEM, 
		"Name=firstName", "Value=Mikhail", ENDITEM, 
		"Name=lastName", "Value=Mikhail", ENDITEM, 
		"Name=address1", "Value=zorge", ENDITEM, 
		"Name=address2", "Value=Kaliningrad", ENDITEM, 
		"Name=register.x", "Value=26", ENDITEM, 
		"Name=register.y", "Value=14", ENDITEM, 
		LAST);

	lr_think_time(9);

	web_submit_form("login.pl_2", 
		"Ordinal=1", 
		"Snapshot=t4.inf", 
		ITEMDATA, 
		"Name=username", "Value=kkk", ENDITEM, 
		"Name=password", "Value=111", ENDITEM, 
		"Name=passwordConfirm", "Value=111", ENDITEM, 
		"Name=firstName", "Value=Mikhail", ENDITEM, 
		"Name=lastName", "Value=Mikhail", ENDITEM, 
		"Name=address1", "Value=zorge", ENDITEM, 
		"Name=address2", "Value=Kaliningrad", ENDITEM, 
		"Name=register.x", "Value=42", ENDITEM, 
		"Name=register.y", "Value=9", ENDITEM, 
		LAST);

	return 0;
}