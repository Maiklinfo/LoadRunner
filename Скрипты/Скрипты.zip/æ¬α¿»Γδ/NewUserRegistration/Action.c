Action()
{


lr_start_transaction("�����������");


	web_submit_form("login.pl_2", 
		"Ordinal=1", 
		"Snapshot=t4.inf", 
		ITEMDATA, 
		"Name=username", "Value=kkk", ENDITEM, 
		"Name=password", "Value=111", ENDITEM, 
		"Name=passwordConfirm", "Value=111", ENDITEM, 
		"Name=firstName", "Value=Mikhail", ENDITEM, 
		"Name=lastName", "Value=Mikhail", ENDITEM, 
		"Name=address1", "Value=zorge", ENDITEM, 
		"Name=address2", "Value=Kaliningrad", ENDITEM, 
		"Name=register.x", "Value=42", ENDITEM, 
		"Name=register.y", "Value=9", ENDITEM, 
		LAST);
lr_end_transaction("�����������", LR_AUTO);

	return 0;
}