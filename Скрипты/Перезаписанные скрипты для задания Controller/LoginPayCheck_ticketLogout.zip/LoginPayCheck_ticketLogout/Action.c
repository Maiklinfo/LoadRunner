Action()
{
lr_start_transaction("login");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Microsoft Edge\";v=\"126\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-User");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_submit_form("login.pl", 
		"Snapshot=t8.inf", 
		ITEMDATA, 
		"Name=username", "Value=zzz", ENDITEM, 
		"Name=password", "Value=111", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
lr_end_transaction("login", LR_AUTO);
lr_start_transaction("fing_flight");


	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t9.inf", 
		LAST);

	web_add_auto_header("Origin", 
		"http://localhost:1080");



	web_submit_form("reservations.pl", 
		"Snapshot=t10.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=07/07/2024", ENDITEM, 
		"Name=arrive", "Value=Denver", ENDITEM, 
		"Name=returnDate", "Value=07/08/2024", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		LAST);
		lr_end_transaction("fing_flight", LR_AUTO);

lr_start_transaction("select_ticket");

	web_submit_form("reservations.pl_2", 
		"Snapshot=t11.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=000;0;07/07/2024", ENDITEM, 
		"Name=reserveFlights.x", "Value=29", ENDITEM, 
		"Name=reserveFlights.y", "Value=11", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Origin", 
		"http://localhost:1080");
	
	lr_end_transaction("select_ticket", LR_AUTO);


lr_start_transaction("payment_details");


	web_submit_form("reservations.pl_3", 
		"Snapshot=t12.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=Mikhail", ENDITEM, 
		"Name=lastName", "Value=Mikhail", ENDITEM, 
		"Name=address1", "Value=zorge", ENDITEM, 
		"Name=address2", "Value=Kaliningrad", ENDITEM, 
		"Name=pass1", "Value=Mikhail Mikhail", ENDITEM, 
		"Name=creditCard", "Value=1111111", ENDITEM, 
		"Name=expDate", "Value=11/11", ENDITEM, 
		"Name=saveCC", "Value=<OFF>", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
lr_end_transaction("payment_details", LR_AUTO);

lr_start_transaction("Check_ticket");


	web_submit_form("reservations.pl_4", 
		"Snapshot=t13.inf", 
		ITEMDATA, 
		"Name=Book Another.x", "Value=32", ENDITEM, 
		"Name=Book Another.y", "Value=9", ENDITEM, 
		LAST);
lr_end_transaction("Check_ticket", LR_AUTO);

	web_revert_auto_header("Origin");
	
lr_start_transaction("logout");

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t14.inf", 
		LAST);
lr_end_transaction("logout", LR_AUTO);

	return 0;
}